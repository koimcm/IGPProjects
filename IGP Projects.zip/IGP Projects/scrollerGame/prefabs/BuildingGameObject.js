class BuildingGameObject extends GameObject{
    constructor(name = "BuildingGameObject"){
        super(name);
        this.addComponent(new Rectangle("lightGray"))
    }
}

window.BuildingGameObject = BuildingGameObject
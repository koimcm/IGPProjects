class FlagGameObject extends GameObject{
    constructor(name = "FlagGameObject"){
        super(name)
        this.addComponent(new FlagComponent())
        this.addComponent(new WinComponent())
    }
}

window.FlagGameObject = FlagGameObject
class ScoreGameObject extends GameObject{
    constructor(name = "ScoreGameObject"){
        super(name)
        this.addComponent(new ScoreComponent())
    }
    start(ctx){
        super.start(ctx)
        this.score = 0
    }
    drawUI(ctx){
        ctx.fillStyle = "black"
        ctx.font = "30px Times"
        ctx.fillText("Score: " + this.score, 25, 40)
    }
}

window.ScoreGameObject = ScoreGameObject
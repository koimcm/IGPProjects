class StartScreenGameObject extends GameObject{
    constructor(name = "StartScreenGameObject"){
        super(name)
        this.addComponent(new StartScreenComponent())
        this.addComponent(new StartInputComponent())
    }
}

window.StartScreenGameObject = StartScreenGameObject
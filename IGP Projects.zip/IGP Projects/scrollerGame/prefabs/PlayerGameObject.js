class PlayerGameObject extends GameObject{
    constructor(name = "PlayerGameObject"){
        super(name)
        this.addComponent(new Circle(60))
        this.addComponent(new PhysicsComponent())
        this.addComponent(new InputComponent())
        this.addComponent(new CameraComponent())
    }
}

window.PlayerGameObject = PlayerGameObject
class CoinGameObject extends GameObject{
    constructor(name = "CoinGameObject"){
        super(name)
        this.addComponent(new Circle(10,"yellow", "gold"))
    }
    
}

window.CoinGameObject = CoinGameObject
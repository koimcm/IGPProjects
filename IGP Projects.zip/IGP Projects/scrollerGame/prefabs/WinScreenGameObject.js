class WinScreenGameObject extends GameObject{
    constructor(name = "StartScreenGameObject"){
        super(name)
        this.addComponent(new WinScreenComponent())
        this.addComponent(new StartInputComponent())
    }
}

window.WinScreenGameObject = WinScreenGameObject
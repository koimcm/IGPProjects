import "/IGP Projects/scrollerGame/prefabs/StartScreenGameObject.js"
import "/IGP Projects/scrollerGame/components/StartScreenComponent.js"
import "/IGP Projects/scrollerGame/components/StartInputComponent.js"


class StartScene extends Scene{
    constructor(){
        super("lightgray")
        this.aspectRatio = .5
        this.logicalWidth = 800
    }
    start(ctx){
        GameObject.instantiate(new StartScreenGameObject())
        
    }
}

window.StartScene = StartScene
// Ideas
// City with bunch of buildnings, have to climb up them
// Trampolines, counter for how high you go, maybe counter for how many jumps you make?
// Have to figure out physics,, how jump works??
// Flag at top to end
import "/IGP Projects/scrollerGame/components/InputComponent.js"
import "/IGP Projects/scrollerGame/components/PhysicsComponent.js"
import "/IGP Projects/scrollerGame/components/FlagComponent.js"
import "/IGP Projects/scrollerGame/components/WinComponent.js"
import "/IGP Projects/scrollerGame/components/ScoreComponent.js"
import "/IGP Projects/scrollerGame/components/CameraComponent.js"

import "/IGP Projects/scrollerGame/prefabs/BuildingGameObject.js"
import "/IGP Projects/scrollerGame/prefabs/PlayerGameObject.js"
import "/IGP Projects/scrollerGame/prefabs/FlagGameObject.js"
import "/IGP Projects/scrollerGame/prefabs/ScoreGameObject.js"
import "/IGP Projects/scrollerGame/prefabs/CoinGameObject.js"


class CityScene extends Scene{
    constructor(){
        super()
        this.aspectRatio = .5
        this.logicalWidth = 800
    }
    start(ctx){
        GameObject.instantiate(new PlayerGameObject(), Engine.currentScene.logicalWidth, Engine.currentScene.logicalWidth, 60,1,1)
        GameObject.instantiate(new BuildingGameObject(), 550, 600, 150, window.innerHeight)
        GameObject.instantiate(new BuildingGameObject(), 300, 500, 150, window.innerHeight)
        GameObject.instantiate(new BuildingGameObject(), 425, 400, 150, window.innerHeight, -2)
        GameObject.instantiate(new BuildingGameObject(), 675, 300, 150, window.innerHeight, -2)
        GameObject.instantiate(new BuildingGameObject(), 925, 200, 150, window.innerHeight, -2)
        GameObject.instantiate(new BuildingGameObject(), 1175, 100, 150, window.innerHeight, -2)
        GameObject.instantiate(new FlagGameObject(), 1225, 40)
        GameObject.instantiate(new ScoreGameObject(), 25, 25)
        GameObject.instantiate(new CoinGameObject(), 625, 575,10) 
        GameObject.instantiate(new CoinGameObject(), 375, 475,10) 
        GameObject.instantiate(new CoinGameObject(), 500, 375,10) 
        GameObject.instantiate(new CoinGameObject(), 750, 275,10) 
        GameObject.instantiate(new CoinGameObject(), 1000, 175,10) 
    }
}

window.CityScene = CityScene
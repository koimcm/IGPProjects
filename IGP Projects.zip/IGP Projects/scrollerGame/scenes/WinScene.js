import "/IGP Projects/scrollerGame/prefabs/WinScreenGameObject.js"
import "/IGP Projects/scrollerGame/components/WinScreenComponent.js"
import "/IGP Projects/scrollerGame/components/StartInputComponent.js"


class WinScene extends Scene{
    constructor(){
        super("green", "green")
        this.aspectRatio = .5
        this.logicalWidth = 800
    }
    start(ctx){
        GameObject.instantiate(new WinScreenGameObject())
    }
}

window.WinScene = WinScene
class ScoreComponent extends Component {
    constructor() {
        super()
    }
    update() {
        let player = GameObject.find("PlayerGameObject")
        let coins = GameObject.filter("CoinGameObject")
        for(let coin of coins){
            if(CollisionsGeometric.isCircle2Circle2Collision(new Circle2(player.transform.x, player.transform.y, player.transform.scaleX),new Circle2(coin.transform.x, coin.transform.y, coin.transform.scaleX))){
                console.log(":3")
                this.parent.score++
                GameObject.destroy(coin)
            }
        }

    }

}

window.ScoreComponent = ScoreComponent
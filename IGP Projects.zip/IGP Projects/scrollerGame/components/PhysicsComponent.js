class PhysicsComponent extends Component {
    //Accel
    //Time off Ground
    //Check for on solid surface
    //Solid surface? maybe for in building objects/ let ground be solid

    constructor() {
        super()
        this.accel = -2
        this.timeOffGround = 0
        this.groundOrNot = true
        this.buffer = true
    }
    update() {
        let buildings = GameObject.filter("BuildingGameObject")
        let sceneY = Engine.currentScene.logicalWidth 
        if (this.transform.y < (sceneY - 62)& this.groundOrNot) {
            this.timeOffGround += 0.3
            this.transform.y += (this.accel * 300 + this.timeOffGround * 300) / Time.fps
            
        }
        else {
            this.timeOffGround = 0
            if (this.transform.y > sceneY - 62) {
                this.transform.y = sceneY - 62
            }
        }
        if(this.timeOffGround > 0.1){
            this.buffer = true
        }
        if (1) {
            for (const building of buildings){
                let platform = new Line2(new Vector2(building.transform.x, building.transform.y), new Vector2(building.transform.x+building.transform.scaleX, building.transform.y))
                if (CollisionsGeometric.isCircle2Line2Collision(this.parent.getComponent("Circle").asGeometry(), platform)) {
                    if(this.parent.transform.y <= building.transform.y){
                        this.groundOrNot = false
                        this.timeOffGround = 0
                        this.parent.transform.y = building.transform.y - 56    
                    }
                }
                else{
                    this.groundOrNot = true
                }
            }
        }
    }
}

window.PhysicsComponent = PhysicsComponent
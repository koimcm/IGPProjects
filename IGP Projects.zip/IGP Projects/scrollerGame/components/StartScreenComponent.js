class StartScreenComponent extends Component{
    constructor(){
        super()
    }
    draw(ctx){
        ctx.fillStyle = "black"
        ctx.font = "30px Times"
        ctx.fillText("Press Spacebar to Begin", 650, 350)
        ctx.fillText("Controls: Left/Right Arrow to move Left/Right and Spacebar to Jump", 350, 400)
        ctx.fillText("Touch the flag to win!", 650, 450)
        
    }
}

window.StartScreenComponent = StartScreenComponent
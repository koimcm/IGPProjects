class CameraComponent extends Component {
    constructor() {
        super()
    }
    start(ctx) {
        Camera.main.transform.x = 0
        Camera.main.transform.y = 0
        Camera.main.transform.scaleX = 1
        Camera.main.transform.scaleY = 1
    }
    update(ctx){
        if(this.transform.y <= 400)
        Camera.main.transform.y = this.transform.y-Engine.currentScene.logicalWidth/2
    }
}

window.CameraComponent = CameraComponent
class StartInputComponent extends Component{
    constructor(){
        super()
    }
    update(){
        
        if (Input.keysDown.includes("Space"))
            setTimeout(() =>Engine.currentScene = new CityScene(),1000)
    }
}

window.StartInputComponent = StartInputComponent
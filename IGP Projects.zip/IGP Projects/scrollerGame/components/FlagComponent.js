class FlagComponent extends Component{
    constructor(){
        super()
    }
    draw(ctx){
        ctx.fillStyle = "seagreen"
        ctx.beginPath()
        ctx.rect(this.transform.x, this.transform.y,
        50, 30)
        ctx.fill()
        ctx.fillStyle = "darkgreen"
        ctx.beginPath()
        ctx.rect(this.transform.x, this.transform.y-10, 10, 70)
        ctx.fill()
    }
}

window.FlagComponent = FlagComponent
class InputComponent extends Component{
    constructor(){
        super()
    }
    update(){
        let speed = 500
        if (Input.keysDown.includes("ArrowLeft"))
            this.transform.x -= speed / Time.fps
        if (Input.keysDown.includes("ArrowRight"))
            this.transform.x += speed / Time.fps
        if (Input.keysDown.includes("Space"))
            this.transform.y -= 5*speed / Time.fps
    }
}

window.InputComponent = InputComponent
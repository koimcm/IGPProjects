class WinComponent extends Component{
    constructor(){
        super()
    }
    update(){
        let player = GameObject.find("PlayerGameObject")
        let flag = GameObject.find("FlagGameObject")
        let isWin = false
        if(CollisionsGeometric.isCircle2Rectangle2Collision(player.getComponent("Circle").asGeometry(),new Rectangle2(flag.transform.x+25, flag.transform.y+25,50,70))){
            isWin = true
        }
        if(isWin){
            Engine.currentScene = new WinScene()
            Camera.main.transform.y = 0
        }
    }
}

window.WinComponent = WinComponent
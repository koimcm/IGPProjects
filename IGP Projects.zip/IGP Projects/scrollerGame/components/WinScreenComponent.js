class WinScreenComponent extends Component{
    constructor(){
        super()
    }
    draw(ctx){
        ctx.fillStyle = "black"
        ctx.font = "30px Times"
        ctx.fillText("Congratulations! You won!", 650, 400)
        ctx.fillText("Press Spacebar to Play Again", 630, 450)
        
    }
}

window.WinScreenComponent = WinScreenComponent
class Globals{

}

window.Globals = Globals
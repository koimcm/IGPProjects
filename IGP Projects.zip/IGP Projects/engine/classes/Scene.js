
class Scene {
    
    gameObjects = []
    hasStarted = false
    logicalWidth = -1
    aspectRatio = -1
    logicalWidthViewWidthInPixels = -1
    logicalWidthViewHeightInPixels = -1
    letterBox1End = 0
    letterBox2Start = 0
    
    constructor(bgColor = "white", letterBoxColor = "lightGray") {
        this.bgColor = bgColor
        this.hasStarted = false
        this.letterBoxColor = letterBoxColor
    }
    
    _start(ctx){
        if(!this.hasStarted){
            this.hasStarted = true
            if (this.start)
                this.start(ctx)
            for (const gObj of this.gameObjects){
                if (gObj.start)
                gObj.start(ctx)
            }
        }
    }

    draw(ctx){
        ctx.fillStyle = this.bgColor
        ctx.fillRect(0,0,ctx.canvas.width, ctx.canvas.height)
        ctx.save()
        let windowAspectRatio = ctx.canvas.height / ctx.canvas.width
        let usingLogicalCoords = this.logicalWidth > 0 && this.aspectRatio > 0
        let logicalHeight = this.logicalWidth * this.aspectRatio
        if (usingLogicalCoords){
            
            if(this.aspectRatio > windowAspectRatio){
                this.letterBox1End = (ctx.canvas.width) / 2 - (ctx.canvas.height / this.aspectRatio) / 2
                this.letterBox2Start = (ctx.canvas.width) / 2 + (ctx.canvas.height / this.aspectRatio) / 2
                ctx.translate(this.letterBox1End, 0)
                let scaleFactor = ctx.canvas.height / this.logicalWidth
                ctx.scale(scaleFactor, scaleFactor)
            }
            else {
                this.letterBox1End = (ctx.canvas.height)/2  - (ctx.canvas.width * this.aspectRatio) /2;
                this.letterBox2Start = (ctx.canvas.width * this.aspectRatio)/2  + (ctx.canvas.height) / 2;
                ctx.translate(0, this.letterBox1End)
                let scaleFactor = ctx.canvas.width / (this.logicalWidth / this.aspectRatio);
                ctx.scale(scaleFactor, scaleFactor)

                this.logicalWidthViewWidthInPixels = ctx.canvas.width;
                this.logicalWidthViewHeightInPixels = this.letterBox2Start - this.letterBox1End;
            }
        }

        ctx.scale(Camera.main.transform.scaleX, Camera.main.transform.scaleY)
        ctx.translate(-Camera.main.transform.x, -Camera.main.transform.y)

        let sortedLayers = [...this.gameObjects]
        sortedLayers = sortedLayers.sort((a, b) => a.layer - b.layer)

        for (const gameObject of sortedLayers) {
            if (gameObject.layer == -1) {
                ctx.filter = "blur(2px)"
            }
            else {
                ctx.filter = "none"
            }
            if (gameObject.draw) {
                gameObject.draw(ctx)
            }
        }
        ctx.restore()
        ctx.fillStyle = this.letterBoxColor

        if (usingLogicalCoords) {
            if (this.aspectRatio > windowAspectRatio) {

                ctx.fillRect(0, 0, this.letterBox1End, ctx.canvas.height)
                ctx.fillRect(this.letterBox2Start, 0, ctx.canvas.width, ctx.canvas.height)
            }
            else {
                ctx.fillRect(0, 0, ctx.canvas.width, this.letterBox1End)
                ctx.fillRect(0, this.letterBox2Start, ctx.canvas.width, ctx.canvas.height)
            }
        }
        for(const gObj of this.gameObjects){
            if(gObj.drawUI)
                gObj.drawUI(ctx)
        }
    }
    update(){
        for(const gObj of this.gameObjects){
            if (gObj.update){
                gObj.update()
            }
        }
    }
}

window.Scene = Scene
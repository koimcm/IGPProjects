import "/IGP Projects/engine/components/Transform.js"


class GameObject {

    components = []
    layer = 0

    constructor(name){
        this.addComponent(new Transform())
        this.name = name
        this.markForDestroy = false
    }

    get transform(){
        return this.components[0]
    }

    addComponent(comp){
        this.components.push(comp)
        comp.parent = this
    }

    start(ctx){
        for (let comp of this.components){
            if (comp.start){
                comp.start(ctx)
            }
        }
    }

    draw(ctx){
        for (let comp of this.components){
            if (comp.draw){
                comp.draw(ctx)
            }
        }
    }
    drawUI(ctx) {
        for (let component of this.components) {
            if (component.drawUI) {
                component.drawUI(ctx)
            }
        }
    }

    update(ctx){
        for (let comp of this.components){
            if (comp.update){
                comp.update(ctx)
            }
        }
    }

    getComponent(name){
        return this.components.find(c=>c.constructor.name == name)
    }
    
    static find(gameObjectName) {
        return Engine.currentScene.gameObjects.find(go => go.name == gameObjectName)
    }

    static filter(gObjName){
        return Engine.currentScene.gameObjects.filter(go => go.name == gObjName)
    }

    static instantiate(gObj, x = 0, y = 0, scaleX = 1, scaleY = 1, layer = 0){
        Engine.currentScene.gameObjects.push(gObj)
        gObj.transform.x = x
        gObj.transform.y = y
        gObj.transform.scaleX = scaleX
        gObj.transform.scaleY = scaleY
        gObj.layer = layer
    }

    static destroy(gObj){
        gObj.markForDestroy = true
    }
}

window.GameObject = GameObject
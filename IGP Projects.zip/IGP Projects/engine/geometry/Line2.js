class Line2{
    constructor(one, two){
      [this.one, this.two] = [one, two]
    }
  }
  
  window.Line2 = Line2
class Rectangle2{
    constructor(centerX, centerY, width, height){
      [this.centerX, this.centerY, this.width, this.height] = [centerX, centerY, width, height]
    }
  }
  
  window.Rectangle2 = Rectangle2
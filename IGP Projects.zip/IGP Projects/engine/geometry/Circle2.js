class Circle2{
    constructor(centerX, centerY, rad){
        [this.centerX, this.centerY, this.rad] = [centerX, centerY, rad]
    }
}

window.Circle2 = Circle2